A Pen created at CodePen.io. You can find this one at https://codepen.io/SitePoint/pen/yNzYqm.

 This example shows how to detect when the user has scrolled into a position and then enable an animation. This one moves an item from the top + left or right using a keyframe animation

Forked from [Simon Codrington](http://codepen.io/simoncodrington/)'s Pen [CSS animations on scroll - Slide in from left](http://codepen.io/simoncodrington/pen/Mwgqqd/).