A Pen created at CodePen.io. You can find this one at https://codepen.io/SitePoint/pen/warKXE.

 This example shows how to detect when the user has scrolled into a position and then enable an animation. This one fades in an animation from the top down

Forked from [Simon Codrington](http://codepen.io/simoncodrington/)'s Pen [CSS animations on scroll - Slide in from left](http://codepen.io/simoncodrington/pen/Mwgqqd/).